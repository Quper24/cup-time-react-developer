export const API_URL = "https://cup-time-api-s9jb.onrender.com";
// /api/products/{category}
